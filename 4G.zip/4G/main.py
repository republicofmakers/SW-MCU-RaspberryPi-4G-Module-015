from machine import UART, Pin, ADC, SPI
import time
from ST7735 import TFT
from sysfont import sysfont

# --- LCD setup ---
spi = SPI(0, baudrate=20_000_000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)  # DC, RST, CS
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)
# --- Intro Screen ---
tft.fill(TFT.BLACK)

tft.text((0, 00), "RP2040", TFT.RED, sysfont, 2)
tft.text((0, 20), "A7672G TEST", TFT.RED, sysfont, 2)
tft.text((0, 40), "Ceyhun Pempeci", TFT.BLUE, sysfont, 2)
tft.text((0, 65), "2025", TFT.GREEN, sysfont, 2)
# UART1 on GPIO8 (TX) and GPIO9 (RX)
uart = UART(1, baudrate=115200, tx=Pin(8), rx=Pin(9))

# Blink LED to confirm start
try:
    led = Pin(25, Pin.OUT)
    for _ in range(5):
        led.toggle(); time.sleep_ms(120)
        led.toggle(); time.sleep_ms(120)
except:
    pass

# ADC on GP26 (pin 31)
adc = ADC(Pin(26))

def read_response(timeout_ms=1000):
    end = time.ticks_add(time.ticks_ms(), timeout_ms)
    buf = bytearray()
    while time.ticks_diff(end, time.ticks_ms()) > 0:
        if uart.any():
            buf.extend(uart.read())
        else:
            time.sleep_ms(10)
    try:
        return buf.decode()
    except:
        return str(buf)

def sendAT(cmd, delay_ms=500):
    uart.write(cmd + "\r\n")
    time.sleep_ms(delay_ms)

def sendAT_Response(cmd, delay_ms=500):
    uart.write(cmd + "\r\n")
    time.sleep_ms(delay_ms)
    resp = read_response(800)
    print("> " + cmd)
    print("< " + (resp if resp else "(no response)"))
    tft.fillrect((0, 12, 160, 10), TFT.BLACK)  # clear line
    tft.text((0, 12), cmd, TFT.YELLOW, sysfont, 1)
    return resp

def mqttPublish(adc_value):
    topic = "A7672-Ceyhun"
    payload = "ADC Value: {}".format(adc_value)

    sendAT_Response('AT+CMQTTTOPIC=0,{}'.format(len(topic)), 120)
    uart.write(topic); uart.write(b"\x1A")
    time.sleep_ms(300)
    read_response(500)

    sendAT_Response('AT+CMQTTPAYLOAD=0,{}'.format(len(payload)), 120)
    uart.write(payload); uart.write(b"\x1A")
    time.sleep_ms(300)
    read_response(500)

    sendAT_Response("AT+CMQTTPUB=0,1,60", 1000)
    print("Published:", payload)
    tft.fillrect((0, 24, 160, 10), TFT.BLACK)
    tft.text((0, 24), "PUB: {}".format(adc_value), TFT.GREEN, sysfont, 1)

def setupA7672G():
    sendAT_Response("AT", 400)
    sendAT_Response("ATE0", 200)
    sendAT_Response("AT+CPIN?", 400)
    sendAT_Response("AT+CGATT=1", 600)
    sendAT_Response('AT+CGDCONT=1,"IP","internet.lguplus.co.kr"', 800)
    sendAT_Response("AT+CGACT=1,1", 1000)
    sendAT_Response("AT+NETOPEN", 1500)
    time.sleep(2)
    sendAT_Response("AT+CMQTTSTART", 600)
    sendAT_Response('AT+CMQTTACCQ=0,"PicoClient"', 400)
    sendAT_Response('AT+CMQTTCONNECT=0,"tcp://broker.hivemq.com:1883",60,1', 3000)

print("Initializing modem...")
tft.text((0, 36), "Init modem...", TFT.GREEN, sysfont, 1)
setupA7672G()

while True:
    value12 = adc.read_u16() >> 4
    mqttPublish(value12)
    tft.fillrect((0, 48, 160, 10), TFT.BLACK)
    tft.text((0, 48), "ADC: {}".format(value12), TFT.CYAN, sysfont, 1)
    time.sleep(5)
